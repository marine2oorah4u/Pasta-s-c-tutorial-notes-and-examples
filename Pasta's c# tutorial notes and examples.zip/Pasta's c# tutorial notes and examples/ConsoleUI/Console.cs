﻿namespace ConsoleUI
{
    internal class Console
    {
        public Console()
        {
        }
    }
}