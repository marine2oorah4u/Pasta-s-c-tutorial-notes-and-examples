﻿using System;
using System.Drawing;
using System.Threading;
using System.Threading.Tasks;
using Colorful;

namespace PastasCSharpNotesAndExamples
{
    public class ProgramIntro
    {
        private static bool stopTyping = false; // Class-level variable
        public static bool isTyping = false;

        public static async Task Run()
        {
            bool isTyping = false;
            stopTyping = false; // Reset the flag each time Run is called

            Colorful.Console.ForegroundColor = Color.FromArgb(220, 158, 61); // orange
            Colorful.Console.WriteLine("\tHello, and welcome to my program!\n");
            await Task.Delay(100);

            Colorful.Console.ForegroundColor = Color.FromArgb(30, 218, 127); // green
            Colorful.Console.WriteLine("\tThis is a program created to showcase\n\t" +
                                 "knowledge I've gained and short or\n\t" +
                                 "smaller programs + apps," +
                                 "created to test\n\t" +
                                 "my C# knowledge and show my progress\n\n\t" +
                                 "My goal is to one day, to prove myself\n\t" +
                                 "and to join the Total Miner Developer ☻\n\n");
            await Task.Delay(100);

            Colorful.Console.ForegroundColor = Color.FromArgb(190, 143, 70);
            Colorful.Console.WriteLine("\tPress any key to continue.");

            string message = "Hello, this is typed out one character at a time!";

            // Start a task to detect key presses
            var keyDetectionTask = Task.Run(() =>
            {
                //System.Console.ReadKey(true); // Wait for any key press
                stopTyping = true; // Set the flag to stop typing

            });

            await TypeOutMessage(message, 50);

            // Ensure that keyDetectionTask is awaited to completion to avoid unhandled exceptions
            await keyDetectionTask;
        }

        static async Task TypeOutMessage(string message, int delay)
        {
            foreach (char c in message)
            {
                if (stopTyping)
                {
                    isTyping = true;

                }

                System.Console.Write(c); // Explicitly use System.Console
                await Task.Delay(delay); // Use Task.Delay for async waiting
            }
            System.Console.WriteLine(); // Explicitly use System.Console
        }
    }
}
