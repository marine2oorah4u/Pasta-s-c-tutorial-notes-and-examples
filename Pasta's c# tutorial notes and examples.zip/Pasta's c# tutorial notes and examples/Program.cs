﻿using System;
using Colorful;
using SysConsole = System.Console;
using ColConsole = Colorful.Console;

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using ConsoleUI;

namespace PastasCSharpNotesAndExamples
{
    class Program
    {

        static async Task Main(string[] args)
        {
            var defaultColor = Color.FromArgb(242, 159, 15);  //orange color
            var numberColor = Color.FromArgb(255, 255, 255);  //white color
            var lightYellow = Color.FromArgb(219, 203, 96);    //light banana like yellow
            var limeGreen = Color.FromArgb(200, 237, 12);      //lime green color
            var lightPurple = Color.FromArgb(170, 12, 237);
            var salmonOrange = Color.FromArgb(245, 183, 140);
            var blueJayBlue = Color.FromArgb(159, 174, 212);
            bool keepRunning = true;

            Colorful.Console.ForegroundColor = defaultColor;
            Colorful.Console.WriteLine("\t\t\n\n\n\tWelcome to my program!\n \tWhat do you want to do?\n\n\n\n\n");

            while (keepRunning)
            {
                Colorful.Console.ForegroundColor = limeGreen;
                Colorful.Console.Write("\t\tChoose an option:\n");

                ////////////////////////////////////////////////////////

                Colorful.Console.ForegroundColor = numberColor;
                Colorful.Console.Write("\t\t1. ");

                Colorful.Console.ForegroundColor = lightYellow;
                Colorful.Console.Write("About my program.\n");  //option 1
                                                                ////////////////////////////////////////////////////////

                Colorful.Console.ForegroundColor = numberColor;
                Colorful.Console.Write("\t\t2. ");

                Colorful.Console.ForegroundColor = salmonOrange;
                Colorful.Console.Write("Run the program.\n");  //option 2
                                                               ////////////////////////////////////////////////////////

                Colorful.Console.ForegroundColor = numberColor;
                Colorful.Console.Write("\t\t3. ");

                Colorful.Console.ForegroundColor = lightPurple;
                Colorful.Console.Write("Exit the program.\n");  //option 3
                                                                ////////////////////////////////////////////////////////

                Colorful.Console.ForegroundColor = blueJayBlue;
                Colorful.Console.Write("\n\n\tEnter your choice: ");
                Colorful.Console.ForegroundColor = Color.FromArgb (255,255,255);


                try
                {
                    int option = Convert.ToInt32(System.Console.ReadLine());

                    // Clear the console to remove the options before executing the selected option
                    System.Console.Clear();

                    switch (option)
                    {
                        case 1:
                            Colorful.Console.ForegroundColor = defaultColor;
                            System.Console.WriteLine("You chose Option 1");
                            Colorful.Console.ResetColor();
                            System.Console.ResetColor();
                            await Task.Delay(500); // Simulating some process

                            ProgramIntro.Run();
                            break;
                        case 2:
                            System.Console.WriteLine("You chose Option 2");
                            // Add your program execution logic here
                            await Task.Delay(500); // Simulating some process
                            break;
                        case 3:
                            System.Console.WriteLine("Exiting program...");
                            keepRunning = false; // Set keepRunning to false to exit the loop
                            break;
                        default:
                            System.Console.WriteLine("Invalid option. Please choose a valid option.");
                            break;
                    }

                    // Optionally wait for a key press before clearing to return to menu
                    if (keepRunning)
                    {
                        System.Console.WriteLine("\nPress any key to return to the main menu...");
                        System.Console.ReadKey(); // Wait for user input before clearing
                        System.Console.Clear(); // Clear console to show the main menu again
                    }
                }
                catch (FormatException)
                {
                    //System.Console.Clear();
                    System.Console.WriteLine("Invalid input. Please enter a number.");
                }
                catch (OverflowException)
                {
                    //System.Console.Clear();
                    System.Console.WriteLine("Input is too large. Please enter a smaller number.");
                }
                catch (Exception ex)
                {
                    //System.Console.Clear();
                    System.Console.WriteLine("An error occurred: " + ex.Message);
                }
            }
        }
    }
}
    